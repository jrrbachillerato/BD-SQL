CREATE DATABASE ParquesNaturales;
USE ParquesNaturales;

CREATE TABLE Visitante (
    DNI char(9),
    Nombre varchar(100) NOT NULL,
    Domicilio varchar(200),
    Profesión varchar(100)
);

CREATE TABLE Excursión (
    CodExcursión int,
    Fecha date,
    Hora time,
    aPie varchar(2),
    CodAlojamiento int
);

CREATE TABLE E_V (
    CodExcursión int,
    DNI char(9)
);

CREATE TABLE Alojamiento (
    CodAlojamiento int,
    Categoria varchar(50),
    Capacidad int,
    CodPN int
);

CREATE TABLE A_V (
    CodAlojamiento int,
    DNI char(9),
    FechaInicio date,
    FechaFin int
);

CREATE TABLE Comunidad_Autonoma (
    CodCA int,
    Nombre varchar(100) NOT NULL,
    OrgResponsable varchar(100)
);

CREATE TABLE Parque_Natural (
    CodPN int,
    Nombre varchar(100) NOT NULL,
    FechaDeclaración date,
    CodCA int
);

CREATE TABLE CA_PN (
    CodCA int,
    CodPN int,
    Superficie decimal(10,2)
);

CREATE TABLE Entrada (
    CodEntrada int,
    CodPN int
);

CREATE TABLE Especie (
    CodEspecie int,
    NombreCientífico varchar(150),
    NombreVulgar varchar(150)
);

CREATE TABLE Animal (
    CodEspecie int,
    Alimentación varchar(100),
    PeriodoCelo varchar(100)
);

CREATE TABLE Vegetal (
    CodEspecie int,
    Floración varchar(100),
    PeriodoFloración varchar(100)
);

CREATE TABLE Mineral (
    CodEspecie int,
    Tipo varchar(100)
);

CREATE TABLE Area (
    NombreA varchar(100) NOT NULL,
    Extensión decimal(10,2),
    CodPN int
);

CREATE TABLE E_A (
    CodEspecie int,
    CodArea varchar(100),
    CantIndividuos int
);

CREATE TABLE Personal (
    DNI char(9),
    NSS varchar(20),
    Nombre varchar(100) NOT NULL,
    Dirección varchar(200),
    TfnoDomicilio char(9),
    TfnoMovil char(9),
    Sueldo decimal(10,2),
    CodPN int
);

CREATE TABLE Conservador (
    DNI char(9),
    Tarea varchar(100),
    NombreA varchar(100)
);

CREATE TABLE Vigilante (
    DNI char(9),
    NombreA varchar(100)
);

CREATE TABLE Investigador (
    DNI char(9),
    Titulación varchar(100)
);

CREATE TABLE Gestor (
    DNI char(9),
    CodEntrada int
);

CREATE TABLE Vehículo (
    Matrícula varchar(20),
    Tipo varchar(50),
    DNI char(9)
);

CREATE TABLE Proyecto (
    CodProy int,
    Presupuesto decimal(15,2),
    FechaInicio date,
    FechaFin date,
    CodEspecie int
);

CREATE TABLE I_P (
    CodProy int,
    DNI char(9)
);



ALTER TABLE Visitante ADD CONSTRAINT PK_Visitante PRIMARY KEY (DNI);
ALTER TABLE Excursión ADD CONSTRAINT PK_Excursión PRIMARY KEY (CodExcursión);
ALTER TABLE E_V ADD CONSTRAINT PK_E_V PRIMARY KEY (CodExcursión, DNI);
ALTER TABLE Alojamiento ADD CONSTRAINT PK_Alojamiento PRIMARY KEY (CodAlojamiento);
ALTER TABLE A_V ADD CONSTRAINT PK_A_V PRIMARY KEY (CodAlojamiento, DNI, FechaInicio);
ALTER TABLE Comunidad_Autonoma ADD CONSTRAINT PK_ComunidadAutonoma PRIMARY KEY (CodCA);
ALTER TABLE Parque_Natural ADD CONSTRAINT PK_ParqueNatural PRIMARY KEY (CodPN);
ALTER TABLE CA_PN ADD CONSTRAINT PK_CA_PN PRIMARY KEY (CodCA, CodPN);
ALTER TABLE Entrada ADD CONSTRAINT PK_Entrada PRIMARY KEY (CodEntrada);
ALTER TABLE Especie ADD CONSTRAINT PK_Especie PRIMARY KEY (CodEspecie);
ALTER TABLE Animal ADD CONSTRAINT PK_Animal PRIMARY KEY (CodEspecie);
ALTER TABLE Vegetal ADD CONSTRAINT PK_Vegetal PRIMARY KEY (CodEspecie);
ALTER TABLE Mineral ADD CONSTRAINT PK_Mineral PRIMARY KEY (CodEspecie);
ALTER TABLE Area ADD CONSTRAINT PK_Area PRIMARY KEY (NombreA);
ALTER TABLE E_A ADD CONSTRAINT PK_E_A PRIMARY KEY (CodEspecie, CodArea);
ALTER TABLE Personal ADD CONSTRAINT PK_Personal PRIMARY KEY (DNI);
ALTER TABLE Conservador ADD CONSTRAINT PK_Conservador PRIMARY KEY (DNI);
ALTER TABLE Vigilante ADD CONSTRAINT PK_Vigilante PRIMARY KEY (DNI);
ALTER TABLE Investigador ADD CONSTRAINT PK_Investigador PRIMARY KEY (DNI);
ALTER TABLE Gestor ADD CONSTRAINT PK_Gestor PRIMARY KEY (DNI);
ALTER TABLE Vehículo ADD CONSTRAINT PK_Vehículo PRIMARY KEY (Matrícula);
ALTER TABLE Proyecto ADD CONSTRAINT PK_Proyecto PRIMARY KEY (CodProy);
ALTER TABLE I_P ADD CONSTRAINT PK_I_P PRIMARY KEY (CodProy, DNI);
ALTER TABLE Personal ADD CONSTRAINT UQ_Personal_NSS UNIQUE (NSS);
ALTER TABLE Vehículo ADD CONSTRAINT UQ_Vehículo_DNI UNIQUE (DNI);








ALTER TABLE Excursión ADD CONSTRAINT FK_Excursión_Alojamiento FOREIGN KEY (CodAlojamiento) REFERENCES Alojamiento (CodAlojamiento) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE E_V ADD CONSTRAINT FK_E_V_Excursión FOREIGN KEY (CodExcursión) REFERENCES Excursión (CodExcursión) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE E_V ADD CONSTRAINT FK_E_V_Visitante FOREIGN KEY (DNI) REFERENCES Visitante (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Alojamiento ADD CONSTRAINT FK_Alojamiento_Parque FOREIGN KEY (CodPN) REFERENCES Parque_Natural (CodPN) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE A_V ADD CONSTRAINT FK_A_V_Alojamiento FOREIGN KEY (CodAlojamiento) REFERENCES Alojamiento (CodAlojamiento) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE A_V ADD CONSTRAINT FK_A_V_Visitante FOREIGN KEY (DNI) REFERENCES Visitante (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Parque_Natural ADD CONSTRAINT FK_ParqueNatural_Comunidad FOREIGN KEY (CodCA) REFERENCES Comunidad_Autonoma (CodCA) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE CA_PN ADD CONSTRAINT FK_CA_PN_Comunidad FOREIGN KEY (CodCA) REFERENCES Comunidad_Autonoma (CodCA) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE CA_PN ADD CONSTRAINT FK_CA_PN_Parque FOREIGN KEY (CodPN) REFERENCES Parque_Natural (CodPN) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Entrada ADD CONSTRAINT FK_Entrada_Parque FOREIGN KEY (CodPN) REFERENCES Parque_Natural (CodPN) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Animal ADD CONSTRAINT FK_Animal_Especie FOREIGN KEY (CodEspecie) REFERENCES Especie (CodEspecie) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Vegetal ADD CONSTRAINT FK_Vegetal_Especie FOREIGN KEY (CodEspecie) REFERENCES Especie (CodEspecie) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Mineral ADD CONSTRAINT FK_Mineral_Especie FOREIGN KEY (CodEspecie) REFERENCES Especie (CodEspecie) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Area ADD CONSTRAINT FK_Area_Parque FOREIGN KEY (CodPN) REFERENCES Parque_Natural (CodPN) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE E_A ADD CONSTRAINT FK_E_A_Especie FOREIGN KEY (CodEspecie) REFERENCES Especie (CodEspecie) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE E_A ADD CONSTRAINT FK_E_A_Area FOREIGN KEY (CodArea) REFERENCES Area (NombreA) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Personal ADD CONSTRAINT FK_Personal_Parque FOREIGN KEY (CodPN) REFERENCES Parque_Natural (CodPN) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Conservador ADD CONSTRAINT FK_Conservador_Personal FOREIGN KEY (DNI) REFERENCES Personal (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Conservador ADD CONSTRAINT FK_Conservador_Area FOREIGN KEY (NombreA) REFERENCES Area (NombreA) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Vigilante ADD CONSTRAINT FK_Vigilante_Personal FOREIGN KEY (DNI) REFERENCES Personal (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Vigilante ADD CONSTRAINT FK_Vigilante_Area FOREIGN KEY (NombreA) REFERENCES Area (NombreA) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Investigador ADD CONSTRAINT FK_Investigador_Personal FOREIGN KEY (DNI) REFERENCES Personal (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Gestor ADD CONSTRAINT FK_Gestor_Personal FOREIGN KEY (DNI) REFERENCES Personal (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Gestor ADD CONSTRAINT FK_Gestor_Entrada FOREIGN KEY (CodEntrada) REFERENCES Entrada (CodEntrada) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Vehículo ADD CONSTRAINT FK_Vehículo_Personal FOREIGN KEY (DNI) REFERENCES Personal (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Proyecto ADD CONSTRAINT FK_Proyecto_Especie FOREIGN KEY (CodEspecie) REFERENCES Especie (CodEspecie) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE I_P ADD CONSTRAINT FK_I_P_Proyecto FOREIGN KEY (CodProy) REFERENCES Proyecto (CodProy) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE I_P ADD CONSTRAINT FK_I_P_Personal FOREIGN KEY (DNI) REFERENCES Personal (DNI) ON DELETE NO ACTION ON UPDATE CASCADE;






ALTER TABLE Visitante ADD CONSTRAINT CK_Visitante_DNI CHECK (DNI = UPPER(DNI));
ALTER TABLE Visitante ADD CONSTRAINT CK_Visitante_Nombre CHECK (Nombre = UPPER(Nombre));
ALTER TABLE Visitante ADD CONSTRAINT CK_Visitante_Domicilio CHECK (Domicilio = UPPER(Domicilio));
ALTER TABLE Visitante ADD CONSTRAINT CK_Visitante_Profesion CHECK (Profesión = UPPER(Profesión));
ALTER TABLE Excursión ADD CONSTRAINT CK_Excursión_aPie CHECK (aPie = UPPER(aPie));
ALTER TABLE Alojamiento ADD CONSTRAINT CK_Alojamiento_Categoria CHECK (Categoria = UPPER(Categoria));
ALTER TABLE Comunidad_Autonoma ADD CONSTRAINT CK_Comunidad_Nombre CHECK (Nombre = UPPER(Nombre));
ALTER TABLE Comunidad_Autonoma ADD CONSTRAINT CK_Comunidad_Org CHECK (OrgResponsable = UPPER(OrgResponsable));
ALTER TABLE Parque_Natural ADD CONSTRAINT CK_Parque_Nombre CHECK (Nombre = UPPER(Nombre));
ALTER TABLE Especie ADD CONSTRAINT CK_Especie_NCientifico CHECK (NombreCientífico = UPPER(NombreCientífico));
ALTER TABLE Especie ADD CONSTRAINT CK_Especie_NVulgar CHECK (NombreVulgar = UPPER(NombreVulgar));
ALTER TABLE Animal ADD CONSTRAINT CK_Animal_Alimentacion CHECK (Alimentación = UPPER(Alimentación));
ALTER TABLE Animal ADD CONSTRAINT CK_Animal_Celo CHECK (PeriodoCelo = UPPER(PeriodoCelo));
ALTER TABLE Vegetal ADD CONSTRAINT CK_Vegetal_Floracion CHECK (Floración = UPPER(Floración));
ALTER TABLE Vegetal ADD CONSTRAINT CK_Vegetal_PFloracion CHECK (PeriodoFloración = UPPER(PeriodoFloración));
ALTER TABLE Mineral ADD CONSTRAINT CK_Mineral_Tipo CHECK (Tipo = UPPER(Tipo));
ALTER TABLE Area ADD CONSTRAINT CK_Area_NombreA CHECK (NombreA = UPPER(NombreA));
ALTER TABLE Personal ADD CONSTRAINT CK_Personal_DNI CHECK (DNI = UPPER(DNI));
ALTER TABLE Personal ADD CONSTRAINT CK_Personal_NSS CHECK (NSS = UPPER(NSS));
ALTER TABLE Personal ADD CONSTRAINT CK_Personal_Nombre CHECK (Nombre = UPPER(Nombre));
ALTER TABLE Personal ADD CONSTRAINT CK_Personal_Direccion CHECK (Dirección = UPPER(Dirección));
ALTER TABLE Conservador ADD CONSTRAINT CK_Conservador_Tarea CHECK (Tarea = UPPER(Tarea));
ALTER TABLE Investigador ADD CONSTRAINT CK_Investigador_Titulacion CHECK (Titulación = UPPER(Titulación));
ALTER TABLE Vehículo ADD CONSTRAINT CK_Vehículo_Matricula CHECK (Matrícula = UPPER(Matrícula));
ALTER TABLE Vehículo ADD CONSTRAINT CK_Vehículo_Tipo CHECK (Tipo = UPPER(Tipo));