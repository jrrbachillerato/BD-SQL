DROP DATABASE IF EXISTS banco;
CREATE DATABASE banco;
USE banco;

CREATE TABLE sucursal(
	CodSucursal int PRIMARY KEY,
    nombre varchar(40),
    direccion varchar(50),
    localidad varchar(50)
);
ALTER TABLE sucursal MODIFY CodSucursal int auto_increment;

CREATE TABLE cliente(
	DNI char(9) PRIMARY KEY,
    nombre varchar(40),
    direccion varchar(50),
    localidad varchar(50),
    FechaNac date,
    sexo varchar(15)
);
CREATE TABLE cuenta(
	CodSucursal int,
    CodCuenta int,
    CONSTRAINT PK PRIMARY KEY(CodSucursal,CodCuenta),
    CONSTRAINT FK_cuenta FOREIGN KEY (CodSucursal) REFERENCES sucursal(CodSucursal) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE transaccion(
	CodSucursal int,
    CodCuenta int,
    NumTransaccion int,
    fecha date,
    cantidad float,
    tipo varchar(30),
    CONSTRAINT PK PRIMARY KEY(CodSucursal,CodCuenta,NumTransaccion),
    CONSTRAINT FK_transaccion FOREIGN KEY(CodSucursal,CodCuenta)REFERENCES cuenta(CodSucursal,CodCuenta) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE cliCuenta(
	CodSucursal int,
    CodCuenta int,
    DNI char(9),
    CONSTRAINT PK PRIMARY KEY(CodSucursal,CodCuenta,DNI),
    CONSTRAINT FK_cliCuenta FOREIGN KEY(CodSucursal,CodCuenta)REFERENCES cuenta(CodSucursal,CodCuenta)ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_cliCuenta2 FOREIGN KEY(DNI)REFERENCES cliente(DNI) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE INDEX Banco_Sucursal ON Sucursal(
	Nombre,
    Localidad
);
CREATE INDEX Banco_Cliente ON Cliente(
	Nombre,
    Localidad
);

CREATE DATABASE pedidos;
USE pedidos;

CREATE TABLE cliente(
	NumCliente int PRIMARY KEY,
    saldo float,
    LimCredito float,
    descuento float
);
ALTER TABLE cliente MODIFY NumCliente int auto_increment;

CREATE TABLE articulo(
	NumArticulo int PRIMARY KEY,
    descripcion varchar(50)
);
ALTER TABLE incluye DROP FOREIGN KEY FK_incluye2;
ALTER TABLE distribuye DROP FOREIGN KEY FK_distribuye;

ALTER TABLE articulo MODIFY NumArticulo int auto_increment;

ALTER TABLE incluye ADD CONSTRAINT FK_incluye2 FOREIGN KEY(NumArticulo) REFERENCES articulo(NumArticulo) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE distribuye ADD CONSTRAINT FK_distribuye FOREIGN KEY(NumArticulo)REFERENCES articulo(NumArticulo) ON DELETE NO ACTION ON UPDATE CASCADE;

CREATE TABLE fabrica(
	NumFabrica int PRIMARY KEY,
    telefono char(9)
);

ALTER TABLE distribuye DROP FOREIGN KEY FK_distribuye2;

ALTER TABLE fabrica MODIFY NumFabrica int auto_increment;

ALTER TABLE distribuye ADD CONSTRAINT FK_distribuye2 FOREIGN KEY(NumFabrica)REFERENCES fabrica(NumFabrica) ON DELETE NO ACTION ON UPDATE CASCADE;

CREATE TABLE direccion(
	CodDireccion int PRIMARY KEY,
    via varchar (40),
    NombreVia varchar (50),
    numero varchar(3),
    piso varchar(2),
    portal varchar(3),
    CodPostal char(5)
);
CREATE TABLE pedido(
	NumPedido int PRIMARY KEY,
    fecha date,
    NumCliente int,
    CodDireccion int,
    CONSTRAINT FK_pedido FOREIGN KEY(NumCliente)REFERENCES cliente(NumCliente) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT FK_pedido2 FOREIGN KEY(CodDireccion)REFERENCES direccion(CodDireccion) ON DELETE SET NULL ON UPDATE CASCADE
);
ALTER TABLE incluye DROP FOREIGN KEY FK_incluye;

ALTER TABLE pedido MODIFY NumPedido int auto_increment;

ALTER TABLE incluye ADD CONSTRAINT FK_incluye FOREIGN KEY(NumPedido)REFERENCES pedido(NumPedido) ON DELETE NO ACTION ON UPDATE CASCADE;

CREATE TABLE posee(
	NumCliente int,
    CodDireccion int,
    CONSTRAINT PK PRIMARY KEY(NumCliente,CodDireccion),
    CONSTRAINT FK_posee FOREIGN KEY(NumCliente)REFERENCES cliente(NumCliente) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_posee2 FOREIGN KEY(CodDireccion)REFERENCES direccion(CodDireccion) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE incluye(
	NumPedido int,
    NumArticulo int,
    cantidad int,
    CONSTRAINT PK PRIMARY KEY(NumPedido,NumArticulo),
    CONSTRAINT FK_incluye FOREIGN KEY(NumPedido)REFERENCES pedido(NumPedido) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_incluye2 FOREIGN KEY(NumArticulo)REFERENCES articulo(NumArticulo) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE distribuye(
	NumArticulo int,
    NumFabrica int,
    CantSuministro int,
    existencias int,
    CONSTRAINT PK PRIMARY KEY(NumArticulo,NumFabrica),
    CONSTRAINT FK_distribuye FOREIGN KEY(NumArticulo)REFERENCES articulo(NumArticulo) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_distribuye2 FOREIGN KEY(NumFabrica)REFERENCES fabrica(NumFabrica) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE DATABASE ventas;
USE ventas;

CREATE TABLE cliente(
	CodCliente int PRIMARY KEY,
    nombre varchar(40),
    calle varchar(50),
    numero varchar(3),
    comuna varchar(20),
    ciudad varchar(30)
);
CREATE TABLE proveedor(
	CodProveedor int PRIMARY KEY,
    nombre varchar(40),
    direccion varchar(50),
    telefono char(9),
    web varchar(50)
);
CREATE TABLE telefono(
	numero char(9) PRIMARY KEY
);
CREATE TABLE categoria(
	IDCategoria int PRIMARY KEY,
    nombre varchar(40),
    descripcion varchar(50)
);
CREATE TABLE producto(
	IDProducto int PRIMARY KEY,
    nombre varchar(40),
    precio float,
    stock int,
    IDCategoria int,
    IDProveedor int,
    CONSTRAINT FK_producto FOREIGN KEY(IDCategoria)REFERENCES categoria(IDCategoria) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT FK_producto2 FOREIGN KEY(IDProveedor)REFERENCES proveedor(CodProveedor) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE venta(
	IDVenta int PRIMARY KEY,
    montoTotal float,
    CodCliente int,
    CONSTRAINT FK_venta FOREIGN KEY(CodCliente)REFERENCES cliente(CodCliente) ON DELETE SET NULL ON UPDATE CASCADE
);

ALTER TABLE incluye DROP FOREIGN KEY FK_incluye;

ALTER TABLE venta MODIFY IDVenta int auto_increment;

ALTER TABLE incluye ADD CONSTRAINT FK_incluye FOREIGN KEY(IDVenta)REFERENCES venta(IDVenta) ON DELETE NO ACTION ON UPDATE CASCADE;

CREATE TABLE incluye(
	IDVenta int,
    IDProducto int,
    cantidad int,
    precioVenta float,
    CONSTRAINT PK PRIMARY KEY(IDVenta,IDProducto),
    CONSTRAINT FK_incluye FOREIGN KEY(IDVenta)REFERENCES venta(IDVenta) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_incluye2 FOREIGN KEY(IDProducto)REFERENCES producto(IDProducto) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE asociado(
	CodCliente int,
    NumTelefono char(9),
    CONSTRAINT PK PRIMARY KEY(CodCliente,NumTelefono),
    CONSTRAINT FK_asociado FOREIGN KEY(CodCliente)REFERENCES cliente(CodCliente) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_asociado2 FOREIGN KEY(NumTelefono)REFERENCES telefono(numero) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE INDEX ventas_cliente ON cliente(
	nombre,
    ciudad
);
CREATE INDEX ventas_categoria ON categoria(
	nombre
);
CREATE INDEX ventas_proveedor ON proveedor(
	nombre
);
CREATE DATABASE cursos;
USE cursos;

CREATE TABLE empleado(
	CodEmpleado int PRIMARY KEY,
    NIF char(9) UNIQUE,
    nombre varchar(40),
    apellidos varchar(50),
    direccion varchar(40),
    telefono char(9),
    fechaNac date,
    salario float
);
CREATE TABLE curso(
	CodCurso int PRIMARY KEY,
    nombre varchar(40),
    duracion varchar(10),
    coste float
);
CREATE TABLE empCapacitado(
	CodEmp int PRIMARY KEY,
    CONSTRAINT FK_empCapacitado FOREIGN KEY(CodEmp)REFERENCES empleado(CodEmpleado) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE empNoCapacitado(
	CodEmp int PRIMARY KEY,
    CONSTRAINT FK_empNoCapacitado FOREIGN KEY(CodEmp)REFERENCES empleado(CodEmpleado) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE prerrequisito(
	CursoSolicitado int,
    CursoPrevio int,
    obligatorio char(1) CHECK (Obligatorio in ("S","N")),
    CONSTRAINT PK PRIMARY KEY(CursoSolicitado,CursoPrevio),
    CONSTRAINT FK_prerrequisito FOREIGN KEY(CursoSolicitado)REFERENCES curso(CodCurso) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_prerrequisito2 FOREIGN KEY(CursoPrevio)REFERENCES curso(CodCurso) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE edicion(
	CodCurso int,
    FechaInicio date,
    lugar varchar(40),
    horario varchar(20),
    profesor int,
    CONSTRAINT PK PRIMARY KEY(CodCurso,FechaInicio),
    CONSTRAINT FK_edicion FOREIGN KEY(CodCurso)REFERENCES curso(CodCurso) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_edicion2 FOREIGN KEY(profesor)REFERENCES empCapacitado(CodEmp) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE recibe(
	CodEmpleado int,
    CodCurso int,
    FechaInicio date,
    CONSTRAINT PK PRIMARY KEY(CodEmpleado,CodCurso,FechaInicio),
    CONSTRAINT FK_recibe FOREIGN KEY(CodEmpleado)REFERENCES empleado(CodEmpleado) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_recibe2 FOREIGN KEY(CodCurso,FechaInicio)REFERENCES edicion(CodCurso,FechaInicio) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE INDEX cursos_empleado ON empleado(
	apellidos
);
CREATE INDEX cursos_edicion ON edicion(
	lugar,
    horario
);

DROP DATABASE IF EXISTS nominas;
CREATE DATABASE nominas;
USE nominas;

CREATE TABLE ccc(
	IdCuenta int PRIMARY KEY,
    CodBanco int UNIQUE,
    CodSucursal int UNIQUE,
    NumCuenta int UNIQUE
);

ALTER TABLE empleado DROP FOREIGN KEY FK_empleado;
ALTER TABLE nomina DROP FOREIGN KEY FK_nomina;

ALTER TABLE ccc modify IdCuenta int auto_increment;

ALTER TABLE empleado ADD CONSTRAINT FK_empleado FOREIGN KEY(IdCuenta)REFERENCES ccc(IdCuenta) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE nomina ADD CONSTRAINT FK_nomina FOREIGN KEY(IdCuenta)REFERENCES ccc(IdCuenta) ON DELETE NO ACTION ON UPDATE CASCADE;

CREATE TABLE departamento(
	CodDpto int PRIMARY KEY,
    nombre varchar(40)
);
CREATE TABLE conceptoRetributivo(
	Cod int PRIMARY KEY,
    descripcion varchar(50)
);
CREATE TABLE sede(
	CodSede int PRIMARY KEY,
    nombre varchar(40),
    CodDpto int,
    CONSTRAINT FK_sede FOREIGN KEY(CodDpto)REFERENCES departamento(CodDpto) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE empleado(
	CodEmp int PRIMARY KEY,
    NIF char(9) UNIQUE,
    nombre varchar(40),
    NumHijos varchar(2),
    retencion float,
    IdCuenta int,
    CONSTRAINT FK_empleado FOREIGN KEY(IdCuenta)REFERENCES ccc(IdCuenta) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE trabaja(
	CodEmp int,
    CodDpto int,
    funcion varchar(30),
    CONSTRAINT PK PRIMARY KEY(CodEmp,CodDpto),
    CONSTRAINT FK_trabaja FOREIGN KEY(CodEmp)REFERENCES empleado(CodEmp) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_trabaja2 FOREIGN KEY(CodDpto)REFERENCES departamento(CodDpto) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE nomina(
	IdNomina int PRIMARY KEY,
    IdCuenta int UNIQUE,
    EjercFiscal int UNIQUE,
    mes varchar(12) UNIQUE,
    NumOrden varchar(5) UNIQUE,
    CodEmp int,
    CONSTRAINT FK_nomina FOREIGN KEY(IdCuenta)REFERENCES ccc(IdCuenta) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_nomina2 FOREIGN KEY(CodEmp)REFERENCES empleado(CodEmp) ON DELETE NO ACTION ON UPDATE CASCADE
);

ALTER TABLE ingreso DROP FOREIGN KEY FK_ingreso;
ALTER TABLE descuento DROP FOREIGN KEY FK_descuento;

ALTER TABLE nomina MODIFY IdNomina int auto_increment;

ALTER TABLE ingreso ADD CONSTRAINT FK_ingreso FOREIGN KEY(IdNomina)REFERENCES nomina(IdNomina) ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE descuento ADD CONSTRAINT FK_descuento FOREIGN KEY(IdNomina)REFERENCES nomina(IdNomina) ON DELETE NO ACTION ON UPDATE CASCADE;

CREATE TABLE ingreso(
	IdNomina int,
    LineaNum int,
    cantidad int,
    concepto int,
    CONSTRAINT PK PRIMARY KEY(IdNomina,LineaNum),
    CONSTRAINT FK_ingreso FOREIGN KEY(IdNomina)REFERENCES nomina(IdNomina) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_ingreso2 FOREIGN KEY(concepto)REFERENCES conceptoRetributivo(Cod) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE descuento(
	IdNomina int,
    LineaNum int,
    cantidad float,
    base float,
    porcentaje float,
    CONSTRAINT PK PRIMARY KEY(IdNomina,LineaNum),
    CONSTRAINT FK_descuento FOREIGN KEY(IdNomina)REFERENCES nomina(IdNomina) ON DELETE NO ACTION ON UPDATE CASCADE
);

