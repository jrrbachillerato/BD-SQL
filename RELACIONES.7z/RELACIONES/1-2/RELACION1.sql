DROP DATABASE IF EXISTS empresa1;
CREATE DATABASE empresa1;
USE empresa1;

CREATE TABLE region(
	CodRegion char(5) PRIMARY KEY,
    Nombre varchar(40)
);

CREATE TABLE provincia(
	CodProvincia char(5) PRIMARY KEY,
    Nombre varchar(40),
    CodRegion char(5),
    CONSTRAINT FK FOREIGN KEY (CodRegion) REFERENCES region(CodRegion) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE localidad(
	CodLocalidad char(5) PRIMARY KEY,
    Nombre varchar(40),
    CodProvincia char(5),
    CONSTRAINT FK1 FOREIGN KEY(CodProvincia) REFERENCES provincia(CodProvincia) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE empleado(
	ID int auto_increment PRIMARY KEY,
    DNI char(9) UNIQUE,
    Nombre varchar(40),
    FechaNacimiento date,
    Telefono char(9),
    Salario float,
    CodLocalidad char(5),
    CONSTRAINT FK2 FOREIGN KEY(CodLocalidad) REFERENCES localidad(CodLocalidad) ON DELETE SET NULL ON UPDATE CASCADE
);
DROP DATABASE IF EXISTS empresa2;
CREATE DATABASE empresa2;
USE empresa2;

CREATE TABLE departamento(
	ID int auto_increment PRIMARY KEY,
    nombre varchar (40),
    ubicacion varchar (40)
);
CREATE TABLE jefe(
	ID int auto_increment PRIMARY KEY,
    DNI char(9) UNIQUE,
    nombre varchar(40),
    salario float,
    telefono char(9),
    IDDep int UNIQUE,
    CONSTRAINT FK FOREIGN KEY (IDDep) REFERENCES departamento(ID) ON DELETE SET NULL ON UPDATE CASCADE
);	
CREATE TABLE empleado(
	ID int auto_increment PRIMARY KEY,
    DNI char(9) UNIQUE,
    nombre varchar(40),
    salario float,
    telefono char(9),
    IDDep int,
    CONSTRAINT FK2 FOREIGN KEY (IDDep) REFERENCES departamento(ID) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE DATABASE ventas;
USE ventas;

CREATE TABLE clientes(
	NIF char(9) PRIMARY KEY,
    nombre varchar(40),
    direccion varchar (60),
    telefono char(9)  
);
CREATE TABLE ModeloDormitorio(
	Cod varchar(10) PRIMARY KEY
);
CREATE TABLE montador(
	NIF char(9) PRIMARY KEY,
	nombre varchar(40),
    direccion varchar (60),
    telefono char(9)  
);
CREATE TABLE compra(
	NIF_C char(9),
    modelo varchar(20),
    fechaCompra date,
    CONSTRAINT PK PRIMARY KEY(NIF_C,modelo,fechaCompra),
    CONSTRAINT FK_compra1 FOREIGN KEY (NIF_C) REFERENCES clientes(NIF) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_compra2 FOREIGN KEY (modelo) REFERENCES ModeloDormitorio(Cod) ON DELETE NO ACTION ON UPDATE CASCADE
);
CREATE TABLE monta(
	modelo varchar(20),
    NIF_C char(9),
    fechaMonta date,
	CONSTRAINT PK PRIMARY KEY(NIF_C,modelo,fechaMonta),
    CONSTRAINT FK_monta1 FOREIGN KEY (modelo) REFERENCES ModeloDormitorio(Cod) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_monta2 FOREIGN KEY (NIF_C) REFERENCES montador(NIF) ON DELETE NO ACTION ON UPDATE CASCADE
);

DROP DATABASE IF EXISTS instituto;
CREATE DATABASE instituto;
USE instituto;

CREATE TABLE profesor(
	IdProfesor int auto_increment PRIMARY KEY,
    NIF_P char(9) UNIQUE,
    nombre varchar(40),
    especialidad varchar (40),
    telefono char(9)
);
CREATE TABLE asignatura(
	CodAsignatura varchar(5) PRIMARY KEY,
    nombre varchar(40),
    IdProfesor int,
    CONSTRAINT FK_asignatura FOREIGN KEY (IdProfesor) REFERENCES profesor(IdProfesor) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE alumnos(
	NumMatricula char(8) PRIMARY KEY,
    nombre varchar(40),
    FechaNacimiento date,
    telefono char(9)
);
CREATE TABLE recibe(
	NumMatricula char(8),
    CodAsignatura varchar(5),
    CursoEscolar varchar (20),
    CONSTRAINT PK PRIMARY KEY (NumMatricula,CodAsignatura,CursoEscolar),
    CONSTRAINT FK_recibe1 FOREIGN KEY (NumMatricula) REFERENCES alumnos(NumMatricula) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_recibe2 FOREIGN KEY (CodAsignatura) REFERENCES asignatura(CodAsignatura) ON DELETE NO ACTION ON UPDATE CASCADE
);