CREATE DATABASE concesionario;
USE concesionario;

CREATE TABLE cliente(
	CodCliente char(5) PRIMARY KEY,
	DNI char(9) UNIQUE,
	nombre varchar(40) NOT NULL,
	direccion varchar (40),
	telefono char(9)
);
CREATE TABLE coche(
	matricula char(4) PRIMARY KEY,
    marca varchar(20) NOT NULL,
    modelo varchar(20) NOT NULL,
    color varchar(10),
    PrecioHora float
);
CREATE TABLE reserva(
	numero int auto_increment PRIMARY KEY,
    FechaInicio date,
    FechaFin date,
    PrecioTotal float,
    CodCliente char(5),
    CONSTRAINT FK_reserva FOREIGN KEY (CodCliente) REFERENCES cliente(CodCliente) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE avala(
	avalado char(5) PRIMARY KEY,
    avalador char(5),
    CONSTRAINT FK_avala1 FOREIGN KEY (avalado) REFERENCES cliente(CodCliente) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_avala2 FOREIGN KEY (avalador) REFERENCES cliente(CodCliente) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE incluye(
	numero int,
    matricula char(4),
	LitrosGas float,
    CONSTRAINT PK_incluye PRIMARY KEY(numero,matricula),
    CONSTRAINT FK_incluye1 FOREIGN KEY (numero) REFERENCES reserva(numero) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK_incluye2 FOREIGN KEY (matricula) REFERENCES coche(matricula) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE DATABASE revista;
USE revista;

CREATE TABLE periodista(
	DNI char(9) PRIMARY KEY,
    nombre varchar(40) NOT NULL,
    direccion varchar (40),
    telefono char(9),
    especialista varchar(20)
);
CREATE TABLE sucursal(
	codigo char(5) PRIMARY KEY,
    direccion varchar (40),
    telefono char(9)
);
CREATE TABLE empleado(
	DNI char(9) PRIMARY KEY,
    nombre varchar(40) NOT NULL,
    direccion varchar (40),
    telefono char(9),
    sucursal char(5),
    CONSTRAINT FK_empleado FOREIGN KEY (sucursal) REFERENCES sucursal(codigo) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE revista(
	NumReg int PRIMARY KEY,
    titulo varchar(20) NOT NULL,
    periodicidad varchar (10) DEFAULT "Mensual",
    tipo varchar(10),
    sucursal char(5),
    CONSTRAINT FK_revista FOREIGN KEY (sucursal) REFERENCES sucursal(codigo) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE escribe(
	NumReg int,
    DNI_Per char(9),
    CONSTRAINT PK_escribe PRIMARY KEY(NumReg,DNI_Per),
    CONSTRAINT FK_escribe1 FOREIGN KEY (NumReg) REFERENCES revista(NumReg) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT FK_escribe2 FOREIGN KEY (DNI_Per) REFERENCES periodista(DNI_Per) ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE NumRevista(
	NumReg int,
    numero int,
    NumPaginas varchar (4),
    fecha date,
    CantVendidas int,
    CONSTRAINT PK_NumRevista PRIMARY KEY(NumReg,numero),
    CONSTRAINT FK_NumRevista FOREIGN KEY (NumReg) REFERENCES revista(NumReg) ON DELETE NO ACTION ON UPDATE CASCADE
);
DROP DATABASE IF EXISTS VideoClub;
CREATE DATABASE VideoClub;
USE VideoClub;

CREATE TABLE Director(
	Nombre varchar(50) PRIMARY KEY,
    Nacionalidad varchar(60)
);

CREATE TABLE Pelicula(
	ID char(5) PRIMARY KEY,
    Titulo varchar(50) NOT NULL,
    Productora varchar(60),
    Nacionalidad varchar(60),
    Fecha date,
    Director varchar(50),
    CONSTRAINT FK6 FOREIGN KEY (Director) REFERENCES Director(Nombre) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Actores(
	Nombre varchar(50) PRIMARY KEY,
    Nacionalidad varchar(60),
    Sexo varchar(20) CHECK (Sexo in ('H', 'M'))
);

CREATE TABLE Actua(
	Actor varchar(50),
    ID_Peli char(5),
    Prota char(1) CHECK (Prota in('S','N')) DEFAULT 'N',
    CONSTRAINT PK PRIMARY KEY(Actor, ID_Peli),
    CONSTRAINT FK7 FOREIGN KEY (Actor) REFERENCES Actores(Nombre) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK8 FOREIGN KEY (ID_Peli) REFERENCES Pelicula(ID) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE TABLE Ejemplar(
	ID_Peli char(5),
    Numero int,
    Estado varchar(40),
    CONSTRAINT PK PRIMARY KEY(ID_Peli, Numero),
    CONSTRAINT FK9 FOREIGN KEY (ID_Peli) REFERENCES Pelicula(ID) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE TABLE Socio(
	DNI char(9) PRIMARY KEY,
    Nombre varchar(50) NOT NULL,
    Direccion varchar(60),
    Telefono char(9),
    Avalador char(9),
    CONSTRAINT FK10 FOREIGN KEY (Avalador) REFERENCES Socio(DNI) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE TABLE Alquila(
	DNI char(9),
    ID_Peli char(5),
    Numero int,
    FechaAlquiler date, 
    FechaDevolucion date,
    CONSTRAINT PK PRIMARY KEY(DNI, ID_Peli, Numero, FechaAlquiler),
    CONSTRAINT FK11 FOREIGN KEY (DNI) REFERENCES Socio(DNI) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK12 FOREIGN KEY (ID_Peli, Numero) REFERENCES Ejemplar(ID_Peli, Numero) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT CH CHECK (FechaDevolucion > FechaAlquiler)
);

DROP DATABASE IF EXISTS Padron;
CREATE DATABASE Padron;
USE Padron;

CREATE TABLE Municipio(
	ID char(5) PRIMARY KEY,
    Nombre varchar(50) NOT NULL,
    CodPostal char(5),
    Provincia varchar(60)
);

CREATE TABLE Vivienda(
	ID char(5) PRIMARY KEY,
    TipoVia varchar(20) DEFAULT 'Calle',
    NombreVia varchar(40) NOT NULL,
    Numero int NOT NULL,
    IDMunicipio char(5),
    CONSTRAINT FK FOREIGN KEY (IDMunicipio) REFERENCES Municipio(ID) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Persona(
	DNI char(9) PRIMARY KEY,
    Nombre varchar(50) NOT NULL,
    FechaNac date,
    Sexo varchar(20) CHECK (Sexo in ('H','M')),
    IDVivienda char(5),
    CONSTRAINT FK2 FOREIGN KEY (IDVivienda) REFERENCES Vivienda(ID) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE CabezaFamilia(
	DNI char(9) PRIMARY KEY,
    IDVivienda char(5) UNIQUE,
    CONSTRAINT FK3 FOREIGN KEY (DNI) REFERENCES Persona(DNI) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK4 FOREIGN KEY (IDVivienda) REFERENCES Vivienda(ID) ON DELETE NO ACTION ON UPDATE CASCADE
);

CREATE TABLE Posee(
	DNI char(9),
    IDVivienda char(5),
    CONSTRAINT PK PRIMARY KEY(DNI,IDVivienda),
    CONSTRAINT FK5 FOREIGN KEY (DNI) REFERENCES Persona(DNI) ON DELETE NO ACTION ON UPDATE CASCADE,
    CONSTRAINT FK6 FOREIGN KEY (IDVivienda) REFERENCES Vivienda(ID) ON DELETE NO ACTION ON UPDATE CASCADE
);

